import React from 'react'
import styled from 'styled-components'
import Footer from './components/Footer';

import Header from './components/Header';

const Body = styled.div`
    //height: 100vh;
    //background-color: rgba(3, 9, 31, 0.9);
    //background: linear-gradient(139.73deg, rgb(25 30 50) 0%,rgb(0 0 0) 100%)
    //background: linear-gradient(139.73deg, rgb(196, 220, 255) 0%, rgb(212 222 255) 100%);
`

const Container = styled.div`
	width: 90%;
	//min-width: 600px;
	margin: 0 auto;
    margin-top: 70px;
`
const StarContainer = styled.div`
    position: absolute;
    top: 0px;
    z-index: -1;
`
const ImageWrapper = styled.div`
    background-image: url('/assets/images/shape-v.png');
    width: 100%;
    //height: 100vh;
    background-size: 100% auto;
    background-repeat: no-repeat;
`

const StarIcon = styled.div`
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background-color: white;
    box-shadow: 0px 0px 20px white;
`




const DefaultLayout = (props) => {
    const { walletButton,  children } = props
    return (
        <ImageWrapper>
            <Body>
                <Header walletButton={walletButton} />
                <Container style={{zIndex:2, minHeight: "calc(100vh - 130px)"}}>
                    {children}
                </Container>
                <Footer />
            </Body>
        </ImageWrapper>
    )
}

export default DefaultLayout