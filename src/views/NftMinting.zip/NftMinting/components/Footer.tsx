import React from 'react'
import styled from 'styled-components';

const FooterContainer = styled.div`
    display: flex;
    height: 60px;
    position: relative;
    background-color: #010101;
    border-top: 1px solid grey;
    color: white;
    font-size: 20px;
    align-items: center;
    justify-content: center;
`

const Footer = () => {
    return (
        <FooterContainer>
            <span>All rights reserved</span>
        </FooterContainer>
    )
}

export default Footer;