import React, { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { Link } from 'react-router-dom'
import styled from 'styled-components'
import { Button } from '@mui/material'
import { styled as muiStyled } from '@mui/material/styles';
import { blue, blueGrey, indigo  } from '@mui/material/colors';
import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import CssBaseline from '@mui/material/CssBaseline';
import useScrollTrigger from '@mui/material/useScrollTrigger';
import Box from '@mui/material/Box';
import Container from '@mui/material/Container';

import IconButton from '@mui/material/IconButton';
import Menu from '@mui/material/Menu';
import MenuIcon from '@mui/icons-material/Menu';
import MenuItem from '@mui/material/MenuItem';

import { setAddress } from '../state/Home'
import { ellipseAddress, getImageUrl } from '../utils'


const HeaderContainer = styled.div`
    width: 100%;
    height: 85px;
    background-color: rgb(223 234 249 / 80%);
    padding-left:30px;
    padding-right:30px;
    position: -webkit-sticky; /* Safari */
    position: sticky;
    top: 0;
    box-shadow: 2px 2px 15px rgb(0 0 0 / 20%);
`

const HeaderWrapper = styled.div`
    position: relative;
    width: 100%;
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
`
const HeaderToggle = styled.div`
    height: 44px;
    @media (min-width: 800px){
        display: none;
    }
`

const Logo = styled.img`
    width: 60px;
    height: auto;
    margin: 10px 8px 4px;
`
const TitleSpan = styled.span`
    position: relative;
    top: 10px;
    line-height: 50px;
    margin-top: 20px;
    margin-bottom: 10px;
    font-size: 30px;
    font-weight: bold;
`

const ColorButton = muiStyled(Button)(({ theme }) => ({
    marginLeft: 20,
    color: theme.palette.getContrastText(indigo[500]),
    backgroundColor: "#e73f76",
    '&:hover': {
      backgroundColor: indigo[800],
    },
}));

const CollectiveButton = muiStyled(Button)(({ theme }) => ({
    color: "#fff",
    background: "linear-gradient(45deg,#e73f76 23%,#e73f76 23%,#873fe6 70%)",
    '&:hover': {
        background: "#fff",
        color: "#e73f76",
        fontWeight: 'bold'
    }
}))

const menuItems = [
    {
        title: 'Mint',
        url: '/mint',
    },
    {
        title: 'Collections',
        url: '/collection',
    },
    {
        title: 'Admin',
        url: '/admin',
    }
];

function ElevationScroll(props) {
    const { children, window } = props;
    // Note that you normally won't need to set the window ref as useScrollTrigger
    // will default to window.
    // This is only being set here because the demo is in an iframe.
    const trigger = useScrollTrigger({
      disableHysteresis: true,
      threshold: 0,
      target: window ? window() : undefined
    });
    console.log("Trigger:", trigger)
    console.log("Props: ", props)
    return React.cloneElement(children, {
      elevation: trigger ? 4 : 0,
      backgroundColor: trigger? "#fff" : "transparent"
    });
}

const Header = (props) => {
    const { walletButton } = props
    const dispatch = useDispatch()
    const address = '0xaCD21f2E7b1B5cA4C321639f5D8b28De3403C6A0'

    const [anchorElNav, setAnchorElNav] = useState(null);
    const [anchorElUser, setAnchorElUser] = useState(null);
  
    const handleCloseNavMenu = () => {
        setAnchorElNav(null);
    };

    const handleOpenNavMenu = (event) => {
        setAnchorElNav(event.currentTarget);
    };
    
    const [ showToast, setShowToast ] = useState(false)
	const [ toastMessage, setToastMessage ] = useState("")
	const [ toastType, setToastType ] = useState(2)

    const onToastClose = () => {
		setShowToast(false);
	}
    const {window} = props
    const trigger = useScrollTrigger({
        disableHysteresis: true,
        threshold: 0,
        target: window ? window() : undefined
    });

    return (
        
        <>
        <CssBaseline />
        
            <AppBar
            style={{
                background: trigger? "#17224af2" : "transparent",
                boxShadow: trigger ? "5px 5px 5px rgba(255,255,255,0.3)!important": ""
            }}>
                <Toolbar>
                    <HeaderWrapper>
                        <div>
                            <Link to="/"><Logo src="assets/images/chronoswap_logo_new.png" alt="logo" /> <TitleSpan style={{color: trigger?"#e7ecff":"#d2e2fd"}}>Chronos</TitleSpan></Link>
                        </div>
                        <div>
                            <Link to="/collectives"><CollectiveButton variant="contained" sx={{borderRadius: 10}}>Collectives</CollectiveButton></Link>
                            { !walletButton ? (<></>) : (
                                address ? (
                                    <ColorButton variant="contained" sx={{borderRadius: 10}}>{ellipseAddress(address)}</ColorButton>
                                ):(
                                    <ColorButton variant="contained" sx={{borderRadius: 10}}>Connect</ColorButton>
                                )
                            )}
                        </div>
                    </HeaderWrapper>
                    <IconButton
                        size="large"
                        aria-label="account of current user"
                        aria-controls="menu-appbar"
                        aria-haspopup="true"
                        onClick={handleOpenNavMenu}
                        color="inherit"
                        sx={{display: {xs: 'block', md: 'none'}, ml: 1, width: 66}}
                        >
                        <MenuIcon />
                    </IconButton>
                    <Menu
                        id="menu-appbar"
                        anchorEl={anchorElNav}
                        anchorOrigin={{
                            vertical: 'bottom',
                            horizontal: 'left',
                        }}
                        keepMounted
                        transformOrigin={{
                            vertical: 'top',
                            horizontal: 'left',
                        }}
                        open={Boolean(anchorElNav)}
                        onClose={handleCloseNavMenu}
                        sx={{
                            display: { xs: 'block', md: 'none' }
                        }}
                        >
                        {menuItems.map((menu) => (
                            <MenuItem key={menu.title} onClick={handleCloseNavMenu}>
                                <Typography textAlign="center">{menu.title}</Typography>
                            </MenuItem>
                        ))}
                    </Menu>
                </Toolbar>
            </AppBar>
      </>
    )
}

export default Header