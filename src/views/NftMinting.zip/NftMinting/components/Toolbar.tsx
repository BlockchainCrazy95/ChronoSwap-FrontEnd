import React from 'react'
import styled from 'styled-components'

import Button from '@mui/material/Button'
import Input from '@mui/material/Input'


const Container = styled.div`
    margin-left: 30px;
    padding: 10px 0px;
    display: flex;
    justify-content: flex-end;
`
const CustomInput = styled.input`
    display: inline;
    border: 1px solid hsla(0,0%,100%,.2);
    background: none;
    padding: 10px 40px 10px 25px;
    color: white!important;
    border-radius: 20px;
    transition: all .5s ease;
    height: 48px;
    font-size: 18px;
    line-height: 24px;
    color: #fff;
    border: 1px solid hsla(0,0%,100%,.4);
    background: none;
    margin-left: 10px;
`

const Toolbar = () => {
    return (
        <Container>
            <Button variant="contained" color="primary" sx={{mr:1}}>Import</Button>
            {/*<CustomInput value={""} placeholder='Collection Name'/>*/}
            <Button variant="contained" color="error" style={{float: 'right'}}>Mint</Button>
        </Container>
    )
}

export default Toolbar