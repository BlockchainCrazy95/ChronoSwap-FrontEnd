export const BSC_BLOCK_TIME = 3

const MAINNET = 25
const TESTNET = 97

export const BASE_BSC_SCAN_URLS = {
    [MAINNET] : 'https://croscan.com',
    [TESTNET] : 'https://testnet.bscscan.com'
}

export const BASE_URL = 'https://localhost:3000'


export const connectorLocalStorageKey = "connectorIdv2"
export const walletLocalStorageKey = "wallet";

// export const provider = "https://bsc-dataseed.binance.org/"
export const provider = "https://rpc-eu.chronoswap.org"

// HoneyMoon
// export const contractAddress = "0x62f5469e44FA07A9C7D62A10898eF7b423Cdcdf6"

// NFTCollectionManager
// export const contractAddress = "0x4Ad73320D323F9BFACF2cB29C218B2bB6048Ba9a"
export const contractAddress = "0x87dfc610BA93d9545A54Ee3043EdbE5a20E8716A"