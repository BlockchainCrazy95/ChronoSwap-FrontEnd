import React, { useState, useEffect, useRef } from 'react';
import { useSelector } from 'react-redux';
import ToggleButtonGroup from '@mui/material/ToggleButtonGroup';
import ToggleButton from '@mui/material/ToggleButton';
import TextField from '@mui/material/TextField';
import Backdrop from '@mui/material/Backdrop';
import CircularProgress from '@mui/material/CircularProgress';
import Button from '@mui/material/Button';
import Box from '@mui/material/Box';
import Slider from '@mui/material/Slider';
import { Input } from '@mui/material';
import styled from 'styled-components';

import DefaultLayout from './Layout'
import LandingSection from './LandingSection'
import NFTCard from './components/NFTCard'

const CollectionInfoSection = styled.section`
	min-height: 500px;
	padding: 80px 30px 20px;
`

const CollectionSection = styled.section`
	//background-image: url('/assets/images/landing.png');
	background-size: 80% auto;
	background-repeat: no-repeat;
	min-height: 760px;
	//height: calc(100vh - 80px - 50px);
	background-position-x: 50%;
	background-position-y: 30%;
	padding: 0px 30px 50px;
`
const CollectionContainer = styled.div`
	margin: 0 auto;
	//background-color: rgba(255, 255, 255, 0.8);
	margin-top: 20px;
	//box-shadow: 2px 2px 2px 1px rgba(0, 0, 0, 0.2);
	border-radius: 5px;
	padding: 10px 15px;
	//border: 1px solid #202020;
	display: flex;
	justify-content: space-between;
	flex-flow: row wrap;
`
const CustomLabel = styled.span`
	font-size: 24px;
	color: white;
	margin: auto;
`
const CustomInput = styled.input`
	display: inline;
	background: none;
	padding: 10px 40px 10px 25px;
	color: white!important;
	border-radius: 20px;
	transition: all .5s ease;
    height: 48px;
    font-size: 18px;
    line-height: 24px;
	color: #fff;
    border: 1px solid hsla(0,0%,100%,.4);
    background: none;
	margin-left: 10px;
`
const styles = {
	title:{
		fontSize: '45px'
	}
}

const getCollectionItems = (items) => {
	if(items.length === 0){
		return <EmptyCollectionContainer/>
	}
	const res = items.map(item => {
		return (<NFTCard />)
	})
	console.log("res =", res)
	if(items.length && items.length % 4 !== 0){
		for(let i = 0;i<4-items.length%4;i++){
			res.push(<NFTCard isEmpty />)
		}
	}
	return res
}

const EmptyCollectionContainer = () => {
	return (
		<div style={{
			width: '100%',
			border: '1px dashed grey',
			borderRadius: 10,
			backgroundColor: "#20202080",
			display: 'flex',
			justifyContent: 'space-around',
		}}>
			<div style={{margin: 'auto'}}>
				<div style={{
					minHeight: 200,
					backgroundImage: "url('/assets/images/gray-image.png')",
					backgroundSize: '100%',
					backgroundRepeat: 'no-repeat'
				}}
				/>
				<span style={{
					fontSize: '30px',
					color: 'grey',
					margin: 'auto 0px'
				}}>Import Or DragDrop...</span>
			</div>
		</div>
	)
}

const Home = () => {

	return (
		<DefaultLayout walletButton>
			<LandingSection />
			{/* <MintingSection />
			<LandingSection />
			<RoadmapSection />
			<FAQSection /> */}
			{/* <CollectionSection>
				<div style={{display: 'flex', justifyContent:'space-between'}}>
					<div className='gradient-text' style={styles.title}>Mint</div>
					<Toolbar
					/>
				</div>
				<CollectionContainer style={{minHeight: 500}}>
					{getCollectionItems(items)}
				</CollectionContainer>
			</CollectionSection> */}
		</DefaultLayout>
	)
}

export default Home;