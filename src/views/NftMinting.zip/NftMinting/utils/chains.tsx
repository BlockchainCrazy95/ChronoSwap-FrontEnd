const supportedChains = [
  {
    name: 'Cronos Mainnet',
    short_name: 'cronos',
    chain: 'cronos',
    network: 'mainnet',
    chain_id: 25,
    network_id: 25,
    rpc_url: 'https://rpc-eu.chronoswap.org',
    native_currency: {
      symbol: 'CRO',
      name: 'CRO',
      decimals: '18',
      contractAddress: '',
      balance: '',
    },
  },
]

export default supportedChains
